<?php 
echo $_GET['photo'];
?>